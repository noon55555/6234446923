import java.util.ArrayList;
public class Order {
    public static int cntOrder = 0; 
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<>();
    public Order(Customer c){
        id=cntOrder+1;
        this.c=c;
    }
    public void addPizza(Pizza piz){
        p.add(piz);
    }
  
    public double calculatePayment(){
        double allPrice = 0;
        for(int i=0;i<=p.size()-1;i++){
            allPrice+=(p.get(i)).getPrice();
        }
        if(c instanceof GoldCustomer){
            allPrice=allPrice*(100-((GoldCustomer)c).getDiscount())/100;
        }
        return allPrice;
}
     public String getOrderDetail(){
        String listPizza = "";
        for(int i=0;i<=p.size()-1;i++){
            listPizza+=(p.get(i)).toString()+"\n";}
        cntOrder++;
        return "Order id : "+id+"\n"+c.toString()+"\n"+listPizza+"Total pieces : "+p.size()+"\nTotal cost : "+this.calculatePayment();
}
}