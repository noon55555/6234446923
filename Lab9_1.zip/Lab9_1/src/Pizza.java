public class Pizza {
    private String name;
    private double price;
    public Pizza(String pizName,double price){
        name = pizName;
        this.price = price;
    }
    public String toString(){
        return name+" price : "+price;
    }
    public double getPrice(){
        return price;
    }
}