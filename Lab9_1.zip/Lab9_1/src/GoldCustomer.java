public class GoldCustomer extends Customer{
    private double discount;
    public GoldCustomer(String name,String tel,double dis){
        super(name,tel);
        discount = dis;
    }
    public String toString(){
        return super.toString()+" discount : "+discount;
    }
    public double getDiscount(){
        return discount;
    }
}