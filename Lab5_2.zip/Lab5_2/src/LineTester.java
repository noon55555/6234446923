import java.awt.geom.Point2D;
public class LineTester {
        public static void main(String[] args) {
            Point2D.Double iPoint = new Point2D.Double();
            Line l1,l2;
            l1 = new Line(-2,1,1,-2);
            l2 = new Line(-6,-2,-2,0);
            
            System.out.println("l1 = new Line(-2,1,1,-2);");
            System.out.println("l2 = new Line(-6,-2,-2,0);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            l1 = new Line(0,2);
            l2 = new Line(2,1);
            
            System.out.println("l1 = new Line(0,2);");
            System.out.println("l2 = new Line(2,1);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            
            
            l1 = new Line(0.44,3.4);
            l2 = new Line(32,32,9);
            
            System.out.println("l1 = new Line(0.44,3.4);");
            System.out.println("l2 = new Line(32,32,9);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            
            l1 = new Line(3,5);
            l2 = new Line(5);
            
            System.out.println("l1 = new Line(3,5);");
            System.out.println("l2 = new Line(5);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            
            l1 = new Line(0,4);
            l2 = new Line(5);
            
            System.out.println("l1 = new Line(0,4);");
            System.out.println("l2 = new Line(5);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            
            l1 = new Line(0.44,3.4);
            l2 = new Line(0.44,5);
            
            System.out.println("l1 = new Line(0.44,3.4);");
            System.out.println("l2 = new Line(0.44,5);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
            
            l1 = new Line(1,-24);
            l2 = new Line(29,5,53,29);
            
            System.out.println("l1 = new Line(1,24);");
            System.out.println("l2 = new Line(29,5,53,29);");
            
            System.out.println("Are the two lines equals?: "+l1.isEquals(l2));
            System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
            System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
            if(l1.isIntersect(l2)){
                 iPoint = l1.getIntersectionPoint(l2);
                System.out.printf("Point of intersection: %.2f,%.2f,%n%n",iPoint.getX(),iPoint.getY());
            }
            else{
                System.out.println("");
            }
    }
}
