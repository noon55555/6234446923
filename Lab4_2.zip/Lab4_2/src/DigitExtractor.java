public class DigitExtractor {
    public int num;
    public int Num;
    
    public DigitExtractor(int anInteger){
        num = anInteger;   
    }
    public int nextDigit() {
        Num = num%10;
        num = num/10;
        return Num;
    }
    
}
