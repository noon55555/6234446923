public class SodaCan {
    private double height;
    private double diameter;
    
    public SodaCan(double H,double D){
        height = H;
        diameter = D;
    }
    public double getVolume(){
        final double volume = height*Math.PI*Math.pow(diameter/2,2);
        return volume;
    }
    public double getSurfaceArea(){
        final double area = (2*Math.PI*(diameter /2)*height) + (2*Math.PI*Math.pow(diameter/2,2));
        return area;
    }
}
