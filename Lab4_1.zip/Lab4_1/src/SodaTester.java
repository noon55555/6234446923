import java.util.Scanner;

public class SodaTester {
    
    public static void main(String[] args){
        System.out.print("Enter height: ");
        Scanner H = new Scanner(System.in);
        Double height = H.nextDouble();
        System.out.print("Enter diameter: ");
        Scanner D = new Scanner(System.in);
        Double diameter = D.nextDouble();
        SodaCan newobject = new SodaCan(height,diameter);
        System.out.println("Volume: "+ String.format("%.2f",newobject.getVolume()));
        System.out.println("Surface area: "+ String.format("%.2f",newobject.getSurfaceArea()));
    }
}
