public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister cash = new CashRegister();
        cash.recordPurchase(50);
        cash.recordPurchase(10);
        cash.recordTaxablePurchase(20);
        cash.enterPayment(100);
        double change = cash.giveChange();
        System.out.println("Your change is " + (float)change);
    }
}