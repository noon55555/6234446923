public class CashRegister {
 private double payment;
    private double purchase;
    private double tax_purchase;
    public  double tax;
    private double change;
    public CashRegister(){
        payment = 0;
        purchase = 0;
        tax_purchase = 0;
        tax = 0.07;
        change = 0;
    }
    public void recordPurchase(double price){
        purchase = purchase + price;
    }
    public void recordTaxablePurchase(double price){
        tax_purchase = price*tax;
        purchase = purchase+price;
    }
    public double getTotalTax(){
        return tax_purchase;
    }
    public void enterPayment(double cash){
        payment = payment + cash;
    }
    public double giveChange() {
        change = payment - (purchase+tax_purchase);
        return change;
    }
}
