package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double amt;
    public TransactionRecord(int t,double a){
        acctNo = t;
        amt = a;
    }
    public int getAcctNo(){ return acctNo; }
    public double getAmt(){ return amt; }
}
