package lab12_3;

import java.util.*;
import java.io.*;

public class FileMatch {
    
    public static void main(String[] args) {
        ArrayList<AccountRecord> accDat = new ArrayList<>();
        ArrayList<TransactionRecord> tranDat = new ArrayList<>();
        
        // Update Balance
        try(
            Scanner acclis = new Scanner(new File("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_3\\src\\lab12_3\\master.txt"));
            Scanner saclis = new Scanner(new File("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_3\\src\\lab12_3\\trans.txt"));
                ){
            while (acclis.hasNextLine()){
                Scanner line = new Scanner(acclis.nextLine());
                accDat.add(new AccountRecord(Integer.parseInt(line.next()),line.next() + " " +line.next(),Double.parseDouble(line.next())));
            }
            while (saclis.hasNextLine()){
                Scanner line = new Scanner(saclis.nextLine());
                tranDat.add(new TransactionRecord(Integer.parseInt(line.next()),Double.parseDouble(line.next())));
            }
            for (AccountRecord a : accDat){
                for (TransactionRecord t : tranDat){
                    a.combine(t);
                }
            }
        }catch(IOException e){
            System.out.println(e);
        }
        
        // Write DAT
        try (RandomAccessFile r = new RandomAccessFile("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_3\\src\\lab12_3\\newMaster.dat","rw")){
            for (AccountRecord a : accDat){
                // int 4 byte
                r.writeInt(a.getAcctNo());
                // char 2 byte * len = 32 = 64
                r.writeChar(' ');
                r.writeChars(a.getName());
                for(int i=0;i<30-(a.getName()).length();i++){
                    r.writeChar(' ');
                }
                r.writeChar(' ');
                // double 8 byte + space 2 byte
                r.writeDouble(a.getBalance());
                r.writeChar(' ');
                // int 4 byte + space 2 byte
                r.writeInt(a.getTransCnt());
                r.writeChars("\n");
            }
        }catch(IOException e){
            System.out.println(e);
        }
        
        // Seek 
        try (RandomAccessFile r = new RandomAccessFile("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_3\\src\\lab12_3\\newMaster.dat","rw")){
            int line = 0;
            double sum = 0;
            int cnt = 0;
            while(r.readLine()!=null)
                line++;
            for (int i=0;i<line;i++){
                r.seek(getPointerBalance(i));
                sum+=r.readDouble();
                r.seek(getPointerTransaction(i));
                if (r.readInt()==0){
                    cnt++;
                }
            }
            System.out.println("Total Account Record : " + line);
            System.out.println("Total balance : " + sum);
            System.out.println("No transaction : " + cnt + " account.");
        }catch(IOException e){
            System.out.println(e);
        }
    }
    
    public static int getPointerTransaction(int line){
        return 78+(line*84);
    }
    
    public static int getPointerBalance(int line){
        return 68+(line*84);
    }
}
