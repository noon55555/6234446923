public class Lab2_2 {
    public static void main(String[] args) {
        String t1 = "Hello, World!";
        String t2 = t1.replace("o","E");
        String t3 = t2.replace("e","o");
        String t4 = t3.replace("E","e");
        System.out.println(t4);
    }
}
