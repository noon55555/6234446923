public class expo extends Taylor{
    public expo(int k,double x){
        super.setIter(k);
        super.setValue(x);
    }
    public double getApprox(){
        int k = super.getIter();
        double x=super.getValue(),ans = 1;
        for(int n=1;n<=k;n++){
            ans+=Math.pow(x,n)/super.factorial(n);
        }
        return ans;
    }
    public void printValue() {
        System.out.println("Value from Math.exp() is "+Math.exp(super.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
}