public class cosine extends Taylor{
    public cosine(int k,double x){
        super.setIter(k);
        super.setValue(x);
    }
    public double getApprox(){
        int k = super.getIter();
        double x=super.getValue(),ans = 1;
        for(int n=1;n<=k;n++){
            ans+=Math.pow(-1,n)*Math.pow(x,(2*n))/super.factorial((2*n));
        }
        return ans;
    }
    public void printValue() {
        System.out.println("Value from Math.exp() is "+Math.cos(super.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
}