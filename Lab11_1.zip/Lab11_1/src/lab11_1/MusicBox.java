package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    ArrayList<String> q = new ArrayList<>();
    @Override
    public void enqueue(Object o){
        q.add((String)o);
        System.out.println((String)o + " is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing " + q.get(0));
        q.remove(0);
    }
}
