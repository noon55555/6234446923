import java.util.ArrayList;
public class ChoiceQuestion extends Question{
    private ArrayList<String> choices = new ArrayList<String>();
    public ChoiceQuestion(String text){
        super(text);
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if (correct){
            setAnswer(choice);
        }
    }
    @Override
    public void display(){
        System.out.println(getText());
        for (int i = 0; i < choices.size(); i++){
            System.out.println((i+1) + ": " + choices.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response){
        return choices.get(Integer.valueOf(response)-1) == getAnswer();
    }
}