package lab10_2;
public class Hybrid extends Bus implements LiquidFuel,Electric {
    double voltage;
    double range;
    int emissionTier;
    public Hybrid(int capacity, double cost,double volt, double range, int emissionTier){
        super(capacity,cost);
        voltage = (volt < LOW_VOLTAGE ? LOW_VOLTAGE : (volt > HIGH_VOLTAGE ? HIGH_VOLTAGE : volt));
        this.range = range;
        this.emissionTier = emissionTier;
    }
    @Override
    public double getAccel(){
        return 4.0;
    }
    @Override
    public int getEmissionTier(){
        return emissionTier;
    }
    @Override
    public double getRange(){
        return range;
    }
    @Override
    public  double getVoltage(){
        return voltage;
    }
}
