package lab10_2;
import java.util.ArrayList;
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Object> arr = new ArrayList<>();
        
        arr.add(new Hybrid(45,1.2E6,999,150,1));
        arr.add(new CNGBus(50,1E6,200,2));
        
        for(Object e : arr){
            System.out.println("ID: " + ((Bus)e).getID());
            if (e instanceof Hybrid){
                System.out.println("Emission Tier: " + ((Hybrid)e).getEmissionTier());
                System.out.println("Accel: " + ((Hybrid)e).getAccel());
            }
            if (e instanceof CNGBus){
                System.out.println("Emission Tier: " + ((CNGBus)e).getEmissionTier());
                System.out.println("Accel: " + ((CNGBus)e).getAccel());
            }
        }
    }
    
}
