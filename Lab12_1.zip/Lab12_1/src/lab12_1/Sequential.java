package lab12_1;

import java.io.*;
import java.util.Scanner;

public class Sequential{
    
    public static void main(String[] args) throws IOException {
        File f = new File("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_1\\src\\lab12_1\\text.txt");
        java.io.PrintWriter out = new PrintWriter(f);
        Scanner input = new Scanner(System.in);
        String line;
        do{
            line = (input.nextLine());
            out.print(!line.equals("quit") ? line + "\n" : "");
        }while(!line.equals("quit"));
        out.close();
        System.out.println("Total characters : " + f.length());
        System.out.println("Total words : " + words(f));
        System.out.println("Total lines : " + line(f));
    }
    
    public static int words(File file) throws IOException{
        int w = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            String line = in.nextLine();      
            w++;
            for (int i=0;i<line.length();i++){
                if (line.charAt(i)==' '){
                    w++;
                }
            }
        }
        in.close();
        return w;
    }
    
    public static int line(File file) throws IOException{
        int l = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            l++;
            in.nextLine();
        }
        in.close();
        return l;
    }
}
