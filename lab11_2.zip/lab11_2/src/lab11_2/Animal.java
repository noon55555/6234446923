package lab11_2;

public abstract class Animal {
    String name;
    
    public Animal(String name){
        this.name = name;
    }
    
    void setName(String name){
        this.name = name;
    }
    
    String getName(){
        return name;
    }
}
