public class Zeller {
    private final int dayOfMonth; 
    private final int month; 
    private int year;
    private int t,d,m,y1,y2;

    public Zeller(int day,int year,int month){
        this.dayOfMonth = day;
        this.month = month;
        this.year = year;
    }
    enum Day{
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        private final String dayOut1; 
        Day (String dayOut){
            this.dayOut1 = dayOut;
        }
        public String get_Day(){
                return dayOut1;
        }
    }
    public Day getDayOfWeek(){
        d = dayOfMonth;
        m = month;
        if (m == 1){year -= 1;m = 13;}
        if (m == 2){year -= 1;m = 14;}
        y1 = year/100;
        y2 = year%100;
        Day getDay = Day.SUNDAY;
        t = (d+((26*(m+1))/10)+y2+(y2/4)+(y1/4)+(y1*5))%7;
        switch(t)
        {
            case 0: getDay =Day.SATURDAY; break;
            case 1: getDay =Day.SUNDAY; break;
            case 2: getDay =Day.MONDAY; break;
            case 3: getDay =Day.TUESDAY; break;
            case 4: getDay =Day.WEDNESDAY; break;
            case 5: getDay =Day.THURSDAY; break;
            case 6: getDay =Day.FRIDAY; break; 
        }
        return getDay;
    } 
}