public class InsectPopulation 
{
    private double numInsect;
    boolean getNumInsect;
    
    public InsectPopulation(double amount)
    {
        numInsect = numInsect + amount;
    }
    public void breed()
    {
        numInsect = numInsect*2;
    }
    public void spray()
    {
        numInsect = numInsect*0.9;
    }
    public double getNumInsect()
    {
        return numInsect;
    }
}