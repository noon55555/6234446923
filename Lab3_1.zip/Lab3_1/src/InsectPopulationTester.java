public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation insectCheck = new InsectPopulation(10);
        insectCheck.breed();
        insectCheck.spray();
        System.out.println("Number of insects: " + insectCheck.getNumInsect());
        insectCheck.breed();
        insectCheck.spray();
        System.out.println("Number of insects: " + insectCheck.getNumInsect());
        insectCheck.breed();
        insectCheck.spray();
        System.out.println("Number of insects: " + insectCheck.getNumInsect());
    }
    
}
