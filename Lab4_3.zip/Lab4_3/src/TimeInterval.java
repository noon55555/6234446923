public class TimeInterval {
    private int imin;
    private int emin;
    
    public TimeInterval(int i, int e){
        int imin = i%100;
        int ihr = i/100;
        int emin = e%100;
        int ehr = e/100;
        this.imin = imin+ihr*60;
        this.emin = emin+ehr*60;
    }
    
    public int getHours(){
        return (emin-imin)/60;
    }
    
    public int getMinutes(){
        return (emin-imin)%60;
    }
}
