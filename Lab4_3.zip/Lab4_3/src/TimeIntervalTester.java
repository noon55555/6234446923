import java.util.Scanner;
public class TimeIntervalTester {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = scan.nextInt();
        System.out.print("Enter end time: ");
        int endTime = scan.nextInt();
        TimeInterval test = new TimeInterval(startTime,endTime);
        System.out.printf("%d hours %d minutes%n",test.getHours(),test.getMinutes());
    }
}
