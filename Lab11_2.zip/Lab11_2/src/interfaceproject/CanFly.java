package interfaceproject;

public interface CanFly {
    void fly(Terrain terrain);
}
