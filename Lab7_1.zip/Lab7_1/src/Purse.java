
import java.util.ArrayList;

public class Purse {
    public ArrayList<String> coins = new ArrayList<>();
    
    public void addCoin(String coinName){
        coins.add(coinName);
    }
            
    @Override
    public String toString(){
        String returnPurse = "Purse" + coins;
        return returnPurse;
    }
    
    public ArrayList<String> reverse(){
        ArrayList<String> newCoins = new ArrayList<>();
	for (int i = coins.size(); i > 0; i--) {
            newCoins.add(coins.get(i - 1));
        }
        return newCoins;
    }
    
    public void transfer(Purse other){
        for (int i = coins.size(); i > 0; i--) {
            other.coins.add(coins.get(0));
            coins.remove(0);
        }
    }
    
    public boolean sameContents(Purse other) {
        if (coins.size() == other.coins.size()) {
            for (int i = 0; i < coins.size(); i++) {
                if (!(coins.get(i).equals(other.coins.get(i)))) {
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    
    public boolean sameCoins(Purse other) {
        ArrayList<String> temp = new ArrayList<String>();
        for (String name : other.coins) {
            temp.add(name);
        }
        if (coins.size() == temp.size()) {
            for (int i = 0; i < coins.size(); i++) {
                for (int j = 0; j < temp.size(); j++) {
                    if (coins.get(i).equals(temp.get(j))) {
                        temp.remove(temp.get(j));
                    }
                }
            }
            if (temp.isEmpty()) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}
