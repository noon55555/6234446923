public class PurseTester {
    
    public static void main(String[] args) {
        Purse a = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Dime");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        a.toString();
        System.out.println(a.toString());
        System.out.println(a.reverse());
        Purse b = new Purse();
        b.addCoin("Dime");
        b.addCoin("Nickel");
        b.toString();
        System.out.println(b.toString());
        System.out.println(b.reverse());
        a.transfer(b);
        System.out.println(a.toString());
        System.out.println(b.toString());
                       
        Purse c = new Purse();
        c.addCoin("Dime");
        c.addCoin("Nickel");
        c.addCoin("Dime");
        c.addCoin("Quarter");
        Purse d = new Purse();
        d.addCoin("Nickel");
        d.addCoin("Dime");
        d.addCoin("Dime");
        d.addCoin("Quarter");
        System.out.println(c.sameContents(d));
        System.out.println(c.sameCoins(d));  
    }
}

        

