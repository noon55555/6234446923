public class CityGridTester {
    public static void main(String[] args) {
        
        double ave=0;
        int max=0;
        int diff=0;
        
        CityGrid test = new CityGrid(10,10);
        for (int i=0 ; i<10000 ; i++){
            for (int j=0 ; j<1000 ; j++){
                if(test.isInCity()){
                 test.walk();
                 ave++;
                }
                else{
                 test.reset();
                 if(max<j){
                     max=j;
                 }
                 break;
                }
            }
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f",ave/10000);
        System.out.println("\nMaximum number of steps that a person can take and is still in the city: "+max);
    }
}