package lab12_2;

import java.io.*;
import java.util.*;

public class WordlistChecker {
    
    public static void main(String[] args){
        
        ArrayList<String> data = new ArrayList<>();
        try{
            Scanner in = new Scanner(new File("C:\\Users\\Sarawut Rimdusit\\Documents\\NetBeansProjects\\Lab12_2\\src\\lab12_2\\wordlist.txt"));
            String line;
            while (in.hasNextLine()){
                line = in.nextLine();
                data.add(line.trim());
            }
        }catch (IOException e){
            System.out.println(e);
        }
        System.out.print("Enter a sentence: ");
        String text = (new Scanner(System.in)).nextLine();
        Scanner t = new Scanner(text);
        System.out.println("Words not contained: ");
        boolean had = false;
        while(t.hasNext()){
            String check = (t.next()).trim();
            if (!data.contains(check)){
                System.out.println(check);
                had = true;
            }
        }
        if (!had){
            System.out.println("N/A");
        }
       
    }
    
}
